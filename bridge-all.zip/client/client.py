
import os
import json
import asyncio
import httpx
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, List
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from cryptography.fernet import Fernet
import uvicorn

load_dotenv()

# --- ENCRYPTED SESSION MANAGEMENT ---
class SessionManager:
    def __init__(self, session_dir="sessions"):
        self.session_dir = session_dir
        self.key = os.getenv("ENCRYPTION_KEY")
        if not self.key:
            # Generate a default key if not provided and save it to .env for the user
            self.key = Fernet.generate_key().decode()
            with open(".env", "a") as f:
                f.write(f"\nENCRYPTION_KEY={self.key}")
            print(f"[!] New encryption key generated and saved to .env")
        
        self.cipher = Fernet(self.key.encode())
        if not os.path.exists(self.session_dir):
            os.makedirs(self.session_dir)

    def _get_file_path(self, provider: str):
        return os.path.join(self.session_dir, f"{provider}.bin")

    def save_session(self, provider: str, data: Dict[str, Any]):
        data["_saved_at"] = datetime.now().isoformat()
        json_data = json.dumps(data).encode()
        encrypted_data = self.cipher.encrypt(json_data)
        with open(self._get_file_path(provider), "wb") as f:
            f.write(encrypted_data)

    def load_session(self, provider: str) -> Optional[Dict[str, Any]]:
        path = self._get_file_path(provider)
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    encrypted_data = f.read()
                decrypted_data = self.cipher.decrypt(encrypted_data)
                return json.loads(decrypted_data)
            except Exception as e:
                print(f"[!] Session decryption failed for {provider}: {e}")
                return None
        return None

    def is_expired(self, session_data: Dict[str, Any]) -> bool:
        ttl = int(os.getenv("SESSION_TTL_HOURS", 24))
        saved_at = datetime.fromisoformat(session_data.get("_saved_at", ""))
        return datetime.now() > saved_at + timedelta(hours=ttl)

# --- PROVIDER ADAPTERS ---
class BaseAdapter:
    def __init__(self, session: Dict[str, Any]):
        self.session = session
        self.cookies = {c['name']: c['value'] for c in session.get("cookies", [])}
        self.headers = session.get("headers", {})
        self.headers["User-Agent"] = session.get("user_agent", "Mozilla/5.0...")

    async def list_models(self) -> List[str]:
        raise NotImplementedError

    async def execute(self, model: str, prompt: str):
        raise NotImplementedError

class ArenaAdapter(BaseAdapter):
    async def list_models(self) -> List[str]:
        return ["gpt-4o", "claude-3-5-sonnet", "gemini-1.5-pro"]

    async def execute(self, model: str, prompt: str):
        return f"[Arena-Encrypted] {model} response to: {prompt}"

class QwenAdapter(BaseAdapter):
    async def list_models(self) -> List[str]:
        return ["qwen-max", "qwen-plus", "qwen-turbo"]

    async def execute(self, model: str, prompt: str):
        return f"[Qwen-Encrypted] {model} response to: {prompt}"

# --- MAIN BRIDGE CLIENT ---
app = FastAPI(title="Bridge-Client Encrypted Gateway")
session_manager = SessionManager()
BRIDGE_SERVER_URL = os.getenv("BRIDGE_SERVER_URL")

async def get_effective_session(provider: str):
    session = session_manager.load_session(provider)
    if not session or session_manager.is_expired(session):
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(f"{BRIDGE_SERVER_URL}/get-session/{provider}", timeout=10)
                if resp.status_code == 200:
                    session = resp.json()
                    session_manager.save_session(provider, session)
                else:
                    raise Exception(f"Server error: {resp.status_code}")
            except Exception as e:
                if not session: raise Exception(f"Auth failed: {str(e)}")
                session = session
    return session

@app.get("/v1/models")
async def list_models():
    all_models = []
    for provider in ["arena", "qwen"]:
        try:
            session = await get_effective_session(provider)
            adapter = ArenaAdapter(session) if provider == "arena" else QwenAdapter(session)
            models = await adapter.list_models()
            for m in models:
                all_models.append({"id": f"bridge/{provider}/{m}", "object": "model"})
        except: continue
    return {"object": "list", "data": all_models}

@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    model_target = body.get("model")
    messages = body.get("messages", [])
    stream = body.get("stream", False)

    if not model_target or "/" not in model_target:
        raise HTTPException(status_code=400, detail="Use format bridge/provider/model")

    parts = model_target.split("/")
    provider_name = parts[1]
    model_id = parts[2]
    prompt = messages[-1]["content"]

    try:
        session = await get_effective_session(provider_name)
        adapter = ArenaAdapter(session) if provider_name == "arena" else QwenAdapter(session)
        
        if stream:
            async def generate():
                res = await adapter.execute(model_id, prompt)
                for char in res:
                    yield f"data: {json.dumps({'choices': [{'delta': {'content': char}}]})}\n\n"
                yield "data: [DONE]\n\n"
            return StreamingResponse(generate(), media_type="text/event-stream")
        else:
            res = await adapter.execute(model_id, prompt)
            return {"choices": [{"message": {"content": res}, "finish_reason": "stop"}], "model": model_target}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health():
    return {"status": "ready", "bridge_server": BRIDGE_SERVER_URL}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
