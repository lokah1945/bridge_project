# 🌐 Bridge-Server Ecosystem (Production Edition)

Sistem ini adalah infrastruktur middleware untuk mengabstraksi sesi browser (cookies/headers) dari berbagai AI Provider menjadi API standar OpenAI.

## 📁 Struktur Paket
- `/server`: Jalankan di Windows Server (Headfull).
- `/client`: Jalankan di Linux/VPS (API Gateway).

---

## 🖥️ Bridge-Server (Node.js)

### Instalasi
1. `npm install`
2. `npx playwright install chromium`
3. `npm start`

### Fitur Multi-Profil
Saat menjalankan `npm start`, Anda akan melihat menu interaktif:
- **(1) Start Server:** Mengaktifkan browser. Jika ada >1 profil, Anda akan diminta memilih.
- **(2) Add New Profile:** Membuat identitas browser baru (folder session terpisah).
- **(3) Delete Profile:** Menghapus data session profil tertentu.

### Cara Login
Akses `http://host.zerotier.my.id:9877/open?url=https://arena.ai/text/direct` untuk membuka browser di server dan login secara manual.

---

## 📱 Bridge-Client (Python)

### Instalasi
1. `pip install -r requirements.txt`
2. Konfigurasi `.env`:
   - `BRIDGE_SERVER_URL`: URL server Windows.
   - `ENCRYPTION_KEY`: Kunci AES (akan digenerate otomatis jika kosong).

### Fitur State-Persistence
Client mengunduh session dari server dan menyimpannya secara **Terenkripsi** di `/sessions`. 
- **Siklus:** Sync $\rightarrow$ Encrypted Local Store $\rightarrow$ Execute.
- **Auto-Refresh:** Jika session expired, client otomatis melakukan sync ulang.

### Penggunaan API
`POST /v1/chat/completions`
Payload: `{"model": "bridge/arena/gpt-4o", "messages": [...]}`
