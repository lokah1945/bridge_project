# 🚀 Bridge-Arena: Local Gateway for Arena Direct

Bridge-Arena adalah gateway lokal yang mengubah antarmuka web Arena Direct menjadi Local HTTP API yang kompatibel dengan format OpenAI.

## 🛠️ Requirements
- Python 3.10+
- Google Chrome / Chromium (diinstall via Playwright)

## 📦 Installation

1. **Clone atau Ekstrak file ini.**
2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Install Browser Engine:**
   ```bash
   playwright install chromium
   playwright install-deps
   ```

## 🚀 How to Use

### 1. Jalankan Gateway
Jalankan server gateway untuk membuka browser stealth di background:
```bash
python3 gateway.py
```
Server akan berjalan di `http://localhost:8000`.

### 2. Menggunakan Local CLI
Gunakan tool CLI untuk interaksi cepat:

- **Cek Status:**
  ```bash
  python3 arena_cli.py health
  ```
- **List Model:**
  ```bash
  python3 arena_cli.py models
  ```
- **Ask Model:**
  ```bash
  python3 arena_cli.py ask --model "Nama-Model" --prompt "Halo!"
  ```

### 3. Integrasi API (OpenAI Compatible)
Anda dapat menghubungkan aplikasi lain ke gateway ini menggunakan endpoint berikut:

- **GET `/v1/models`**: Mengambil daftar model.
- **POST `/v1/chat/completions`**: Mengirim pesan (Support Streaming).
  - Payload: `{"model": "...", "messages": [{"role": "user", "content": "..."}], "stream": true}`

## 🛡️ Stealth Mode
Sistem ini menggunakan `playwright-stealth` dan konfigurasi khusus untuk meminimalisir deteksi bot oleh Cloudflare dan reCAPTCHA. Pastikan Anda tidak menjalankan request dalam volume yang terlalu ekstrem untuk menghindari rate-limit IP.
