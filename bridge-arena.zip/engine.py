
import asyncio
from playwright.async_api import async_playwright
from playwright_stealth import stealth

class ArenaEngine:
    def __init__(self):
        self.browser = None
        self.context = None
        self.page = None

    async def start(self):
        pw = await async_playwright().start()
        # Launch browser with stealth arguments
        self.browser = await pw.chromium.launch(
            headless=True, 
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-web-security",
                "--disable-features=IsolateOrigins,site-per-process"
            ]
        )
        self.context = await self.browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080}
        )
        self.page = await self.context.new_page()
        
        # Apply stealth plugin
        await stealth(self.page)
        
        await self.page.goto("https://arena.ai/text/direct", wait_until="networkidle")
        print("[Engine] Browser started and stealth applied.")

    async def get_models(self):
        # Scrape models from the dropdown
        try:
            # Wait for the model selector to appear
            await self.page.wait_for_selector("button[role='combobox']", timeout=10000)
            await self.page.click("button[role='combobox']")
            await self.page.wait_for_selector("[role='listbox']", timeout=5000)
            
            models = await self.page.eval_on_selector_all(
                "[role='option']", 
                "elements => elements.map(e => e.innerText)"
            )
            return models
        except Exception as e:
            print(f"[Engine] Error fetching models: {e}")
            return []

    async def chat_stream(self, model_name, prompt):
        try:
            # 1. Select Model
            await self.page.click("button[role='combobox']")
            await self.page.wait_for_selector(f"text={model_name}", timeout=5000)
            await self.page.click(f"text={model_name}")
            
            # 2. Send Prompt
            textarea = await self.page.wait_for_selector("textarea")
            await textarea.fill(prompt)
            await self.page.keyboard.press("Enter")
            
            # 3. Capture Response Stream
            # We look for the last response element that is updating
            last_response_selector = ".bot-response-text" # Placeholder, will be refined by actual DOM
            
            # For streaming, we poll the last element's content
            previous_text = ""
            while True:
                # Wait for response to start
                await self.page.wait_for_selector(".bot-response-text", timeout=30000)
                responses = await self.page.query_selector_all(".bot-response-text")
                if not responses:
                    break
                
                current_text = await responses[-1].inner_text()
                if current_text == previous_text:
                    # Check if the "stop" button disappeared or "send" button reappeared
                    # to determine if streaming is finished
                    if await self.page.is_visible("button[aria-label='Send message']"):
                        break
                    await asyncio.sleep(0.5)
                else:
                    delta = current_text[len(previous_text):]
                    previous_text = current_text
                    yield delta
                    
        except Exception as e:
            yield f"Error: {str(e)}"

    async def stop(self):
        if self.browser:
            await self.browser.close()
